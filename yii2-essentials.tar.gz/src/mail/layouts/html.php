<?php
/** @var yii\web\View $this */
$this->title = '';
?>
<?php $this->beginPage() ?>
<?= $content ?>
<?php $this->endPage() ?>
