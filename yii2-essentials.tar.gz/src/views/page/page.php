<h1><?= $model->title; ?></h1>
<?= $model->content; ?>