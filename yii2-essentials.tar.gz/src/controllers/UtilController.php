<?php

namespace croacworks\essentials\controllers;

/**
 * FileController implements the CRUD actions for File model.
 */
class UtilController extends AuthorizationController{}