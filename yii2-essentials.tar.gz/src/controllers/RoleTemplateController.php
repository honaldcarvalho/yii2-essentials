<?php

namespace croacworks\essentials\controllers;

use croacworks\essentials\models\RoleTemplate;
use yii\web\NotFoundHttpException;

/**
 * RoleTemplateController implements the CRUD actions for RoleTemplateController model.
 */
class RoleTemplateController extends AuthorizationController
{

    /**
     * Lists all RoleTemplateController models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new RoleTemplate();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single RoleTemplateController model.
     * @param int $id ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new RoleTemplateController model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model =  new RoleTemplate();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'id' => $model->id]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing RoleTemplateController model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $post = $this->request->post();
        $savedActions = $model->actions ? explode(';', $model->actions) : [];

        if ($this->request->isPost && $model->load($post)) {
            $model->actions = isset($post['to']) ? implode(';', $post['to']) : null;
            $model->controller = trim($model->controller);
            $model->origin = isset($post['RoleTemplate']['origin']) ? implode(';', $post['RoleTemplate']['origin']) : '*';

            if ($model->save()) {
                return $this->redirect(['view', 'id' => $model->id]);
            }
        }

        return $this->render('update', [
            'model' => $model,
            'savedActions' => $savedActions,
        ]);
    }

    /**
     * Deletes an existing RoleTemplateController model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $id ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

}
